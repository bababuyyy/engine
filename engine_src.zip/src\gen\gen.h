#pragma once
#include "level/level.h"
#include <cstdint>

// Header puro: Sem depend�ncias de simula��o f�sica, SDL, ImGui ou tipos GLM

namespace gen {
    struct GridData {
        bool cells[96][96];
        int spawn_x;
        int spawn_z;
        int room_count;
    };

    struct GenResult {
        level::LevelData level;
        uint64_t layout_hash;
        int room_count;
        int box_count;
    };

    // Exportado separadamente para prop�sitos de teste (valida��o de conectividade Headless)
    GridData gen_grid(uint64_t seed);

    // Gera��o master do dom�nio de masmorras retornando LevelData can�nico
    GenResult gen_dungeon(uint64_t seed);

    // Hash do layout para teste de determinismo e rastreio estrutural (FNV-1a)
    uint64_t gen_layout_hash(const level::LevelData& data);
}