#pragma once
#include <cstdint>

// Header agn�stico: PROIBIDA a inclus�o de SDL, ImGui, GLM, sim.h ou headers sujos do Jolt.
// A interface p�blica exp�e apenas plain-old-data (POD) seguros.

namespace phys {

    struct PhysInput {
        float vx;
        float vy;
        float vz;
        float gravity_y; // Usado estritamente como vetor direcional do mundo para o ExtendedUpdate
        float stick_step_down = 0.5f;
        bool walk_stairs_on = true;
    };

    struct PhysState {
        float x;
        float y;
        float z;
        float vx;
        float vy;
        float vz;
        float gvx; // Componentes da velocidade relativa do ch�o (plataformas m�veis)
        float gvy;
        float gvz;
        bool on_ground;
    };

    void phys_init();
    void phys_shutdown();

    // Cria colisores est�ticos e retorna a ID Jolt embutida num descritor gen�rico (necess�rio pro F5 Reload)
    uint32_t phys_create_static_box(float px, float py, float pz, float hx, float hy, float hz, float rot_yaw = 0.0f, float rot_pitch = 0.0f);
    uint32_t phys_create_mesh_shape(const float* vertices, size_t vertex_count, const uint16_t* indices, size_t index_count);
    void phys_destroy_body(uint32_t id);

    // Cria um colisor moviment�vel pela API sem assimila��o de for�as, retornando a ID atrelada
    uint32_t phys_create_kinematic_box(float px, float py, float pz, float hx, float hy, float hz);
    void phys_move_kinematic(uint32_t id, float x, float y, float z);

    // Injeta a c�psula do CharacterVirtual no ecossistema f�sico
    void phys_create_character(float px, float py, float pz);

    // Controle e teleporte atrelado �s chaves de dev-tool
    void phys_teleport_character(float px, float py, float pz);
    bool phys_resize_character(bool agachado);

    // Atualiza caches espaciais do Kernel para curar dead-stops logo ap�s os teleportes/reloads
    void phys_refresh_contacts();

    // Cast simples do NarrowPhaseQuery para testar vis�o da c�mera de forma determin�stica e segura
    float phys_camera_ray(float fx, float fy, float fz, float dx, float dy, float dz, float max_dist);

    // Chamada isolada por tick: Consome input, processa a atualiza��o global e retorna estado atual
    PhysState phys_update_character(const PhysInput& input);
}